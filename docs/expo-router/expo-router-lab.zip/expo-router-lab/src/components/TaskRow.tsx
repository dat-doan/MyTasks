import { Link } from 'expo-router';
import { Pressable, StyleSheet, Text } from 'react-native';
import type { Task } from '../contexts/TasksContext';

export function TaskRow({ task }: { task: Task }) {
  return (
    <Link href={{ pathname: '/tasks/[id]', params: { id: task.id, tags: 'router,lab' } }} asChild>
      <Pressable style={styles.row} accessibilityLabel={`Xem ${task.title}`}>
        <Text style={styles.status}>{task.completed ? '✓ Đã xong' : '○ Chưa xong'}</Text>
        <Text style={styles.title}>{task.title}</Text>
        <Text style={styles.hint}>/tasks/{task.id} →</Text>
      </Pressable>
    </Link>
  );
}

const styles = StyleSheet.create({
  row: { backgroundColor: '#fff', padding: 18, borderRadius: 16, gap: 7 },
  status: { color: '#155eef', fontWeight: '600' },
  title: { color: '#17253f', fontSize: 18, fontWeight: '600' },
  hint: { color: '#5d6c84' },
});
