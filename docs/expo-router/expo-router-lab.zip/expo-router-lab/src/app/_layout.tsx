import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { TasksProvider } from '../contexts/TasksContext';

// Giữ Tabs làm màn hình nền khi mở thẳng detail hoặc modal từ deep link.
export const unstable_settings = { anchor: '(tabs)' };

export default function RootLayout() {
  return (
    <TasksProvider>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerTintColor: '#155eef', contentStyle: { backgroundColor: '#f5f7fb' } }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="tasks/[id]" options={{ title: 'Chi tiết công việc' }} />
        <Stack.Screen name="tasks/new" options={{ title: 'Tạo công việc', presentation: 'modal' }} />
        <Stack.Screen name="+not-found" options={{ title: 'Không tìm thấy trang' }} />
      </Stack>
    </TasksProvider>
  );
}
