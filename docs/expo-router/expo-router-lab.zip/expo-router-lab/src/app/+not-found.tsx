import { Link } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';

export default function NotFoundScreen() {
  return (
    <View style={styles.screen}>
      <Text style={styles.title}>Không có trang này</Text>
      <Text style={styles.text}>URL không khớp với route nào trong src/app.</Text>
      <Link href="/(tabs)/tasks" dismissTo style={styles.link}>Mở danh sách công việc</Link>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, justifyContent: 'center', padding: 24, gap: 20, backgroundColor: '#f5f7fb' },
  title: { color: '#17253f', fontSize: 28, fontWeight: '700' },
  text: { color: '#44546f', fontSize: 17, lineHeight: 26 },
  link: { color: '#155eef', fontSize: 17, paddingVertical: 12 },
});
