import { ScrollView, StyleSheet, Text } from 'react-native';
import { useTasks } from '../../contexts/TasksContext';

export default function SettingsScreen() {
  const { tasks } = useTasks();

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Dữ liệu đi cùng layout</Text>
      <Text style={styles.text}>Hiện có {tasks.length} công việc trong TasksProvider.</Text>
      <Text style={styles.text}>
        Provider bọc Root Stack nên Tabs, màn hình chi tiết và modal dùng chung dữ liệu.
        Chuyển tab không làm mất danh sách.
      </Text>
      <Text style={styles.text}>
        Đây là dữ liệu trong bộ nhớ. Reload toàn bộ ứng dụng hoặc khởi động lại sẽ
        khôi phục 2 công việc mẫu. Fast Refresh có thể giữ hoặc reset state.
      </Text>
      <Text style={styles.text}>
        (tabs) là route group: giúp tổ chức navigator và không xuất hiện trong URL công khai.
        Màn hình chi tiết và tạo mới ở ngoài nhóm nên không có tab bar.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#f5f7fb' },
  content: { padding: 24, gap: 18, paddingBottom: 40 },
  title: { color: '#17253f', fontSize: 27, fontWeight: '700' },
  text: { color: '#44546f', fontSize: 17, lineHeight: 27 },
});
