import { Link } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { TaskRow } from '../../../components/TaskRow';
import { useTasks } from '../../../contexts/TasksContext';

export default function TasksScreen() {
  const { tasks } = useTasks();
  const completed = tasks.filter((task) => task.completed).length;

  return (
    <FlatList
      style={styles.screen}
      contentContainerStyle={styles.content}
      data={tasks}
      keyExtractor={(task) => task.id}
      renderItem={({ item }) => <TaskRow task={item} />}
      ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
      ListHeaderComponent={
        <View style={styles.header}>
          <Text style={styles.title}>Router Lab</Text>
          <Text style={styles.caption}>{completed}/{tasks.length} công việc đã hoàn thành</Text>
          <Link href="/tasks/new" asChild>
            <Pressable style={styles.button} accessibilityRole="button">
              <Text style={styles.buttonText}>+ Tạo công việc</Text>
            </Pressable>
          </Link>
        </View>
      }
      ListEmptyComponent={<Text>Chưa có công việc nào. Hãy tạo công việc đầu tiên.</Text>}
    />
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#f5f7fb' },
  content: { padding: 20, paddingBottom: 32 },
  header: { gap: 12, marginBottom: 20 },
  title: { fontSize: 30, fontWeight: '700', color: '#17253f' },
  caption: { color: '#5d6c84', fontSize: 16 },
  button: { backgroundColor: '#155eef', borderRadius: 12, padding: 16 },
  buttonText: { color: '#fff', fontWeight: '700', textAlign: 'center' },
});
