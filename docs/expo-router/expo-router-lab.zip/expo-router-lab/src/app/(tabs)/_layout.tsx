import { Tabs } from 'expo-router';
import { Text } from 'react-native';

export default function TabsLayout() {
  return (
    <Tabs initialRouteName="tasks/index" screenOptions={{ tabBarActiveTintColor: '#155eef' }}>
      <Tabs.Screen name="index" options={{ href: null }} />
      <Tabs.Screen name="tasks/index" options={{
        title: 'Công việc',
        tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 20 }}>✓</Text>,
      }} />
      <Tabs.Screen name="settings" options={{
        title: 'Ghi chú',
        tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 20 }}>ⓘ</Text>,
      }} />
    </Tabs>
  );
}
