import { router } from 'expo-router';
import { useState } from 'react';
import { Button, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput } from 'react-native';
import { useTasks } from '../../contexts/TasksContext';

export default function NewTaskScreen() {
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const { addTask } = useTasks();

  function save() {
    if (title.trim().length < 3) {
      setError('Tiêu đề cần ít nhất 3 ký tự, không tính khoảng trắng đầu/cuối.');
      return;
    }
    const id = addTask(title, notes);
    // Thay modal bằng detail: Back từ detail không quay lại form vừa lưu.
    router.replace({ pathname: '/tasks/[id]', params: { id } });
  }

  function cancel() {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)/tasks');
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Tạo một công việc</Text>
        <Text style={styles.caption}>Đây là route /tasks/new được trình bày dạng modal.</Text>
        <Text style={styles.label}>Tiêu đề</Text>
        <TextInput style={styles.input} value={title} onChangeText={(value) => {
          setTitle(value);
          setError('');
        }} placeholder="Ví dụ: Thử router.replace" accessibilityLabel="Tiêu đề công việc"
          maxLength={120} autoFocus returnKeyType="next" />
        <Text style={styles.label}>Ghi chú</Text>
        <TextInput style={[styles.input, styles.notes]} value={notes} onChangeText={setNotes}
          placeholder="Ghi điều bạn vừa học..." accessibilityLabel="Ghi chú công việc"
          multiline maxLength={1000} />
        {error ? <Text style={styles.error} accessibilityRole="alert">{error}</Text> : null}
        <Button title="Lưu và mở chi tiết" onPress={save} />
        <Button title="Hủy" onPress={cancel} color="#5d6c84" />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#f5f7fb' },
  content: { padding: 24, paddingBottom: 48, gap: 16 },
  title: { color: '#17253f', fontSize: 27, fontWeight: '700' },
  caption: { color: '#5d6c84', lineHeight: 23 },
  label: { color: '#17253f', fontWeight: '600', fontSize: 16 },
  input: { borderWidth: 1, borderColor: '#cfd7e6', borderRadius: 12, padding: 16, backgroundColor: '#fff', fontSize: 16 },
  notes: { minHeight: 120, textAlignVertical: 'top' },
  error: { color: '#b42318', lineHeight: 22 },
});
