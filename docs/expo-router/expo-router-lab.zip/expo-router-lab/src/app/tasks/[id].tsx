import { Link, Stack, useLocalSearchParams } from 'expo-router';
import { Button, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useTasks } from '../../contexts/TasksContext';

export default function TaskDetailScreen() {
  // Generic mô tả dữ liệu; kiểm tra runtime vẫn cần cho URL từ bên ngoài.
  const params = useLocalSearchParams<{ id?: string | string[]; tags?: string | string[] }>();
  const id = typeof params.id === 'string' && params.id.trim() ? params.id : undefined;
  const tags = (Array.isArray(params.tags) ? params.tags : [params.tags ?? ''])
    .flatMap((value) => value.split(','))
    .map((value) => value.trim())
    .filter(Boolean);
  const { tasks, toggleTask } = useTasks();
  const task = id ? tasks.find((item) => item.id === id) : undefined;

  if (!task) {
    return (
      <View style={styles.content}>
        <Text style={styles.title}>Không tìm thấy công việc</Text>
        <Text style={styles.text}>
          {id ? `ID “${id}” chưa có trong dữ liệu hiện tại.` : 'URL thiếu ID hợp lệ.'}
          {' '}Công việc vừa tạo sẽ mất khi reload vì lab dùng dữ liệu trong bộ nhớ.
        </Text>
        <Link href="/(tabs)/tasks" dismissTo style={styles.link}>Về danh sách</Link>
      </View>
    );
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Stack.Screen options={{ title: `Công việc #${task.id}` }} />
      <Text style={styles.eyebrow}>PATH PARAM · id = {task.id}</Text>
      <Text style={styles.title}>{task.title}</Text>
      <Text style={styles.text}>{task.notes || 'Chưa có ghi chú.'}</Text>
      <Text style={styles.text}>Trạng thái: {task.completed ? 'Đã hoàn thành' : 'Đang làm'}</Text>
      <Button title={task.completed ? 'Đánh dấu chưa xong' : 'Đánh dấu hoàn thành'}
        onPress={() => toggleTask(task.id)} />
      <Text style={styles.eyebrow}>QUERY PARAM · tags</Text>
      <Text style={styles.text}>{tags.length ? tags.join(' · ') : 'Không truyền tags trong URL.'}</Text>
      <Text style={styles.small}>URL chỉ mang ID và bộ lọc. Nội dung công việc được lấy từ Context.</Text>
      <Link href="/(tabs)/tasks" dismissTo style={styles.link}>Về danh sách</Link>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#f5f7fb' },
  content: { padding: 24, gap: 20, paddingBottom: 40 },
  title: { fontSize: 28, fontWeight: '700', color: '#17253f' },
  text: { color: '#44546f', fontSize: 17, lineHeight: 27 },
  eyebrow: { fontSize: 12, fontWeight: '700', color: '#155eef' },
  small: { color: '#5d6c84', fontSize: 14, lineHeight: 22 },
  link: { color: '#155eef', fontSize: 17, paddingVertical: 12 },
});
