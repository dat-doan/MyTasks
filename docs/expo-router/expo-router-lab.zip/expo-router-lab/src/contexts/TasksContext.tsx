import { createContext, useContext, useRef, useState, type ReactNode } from 'react';

export type Task = {
  id: string;
  title: string;
  notes: string;
  completed: boolean;
};

type TasksState = {
  tasks: Task[];
  addTask: (title: string, notes: string) => string;
  toggleTask: (id: string) => void;
};

const initialTasks: Task[] = [
  { id: '1', title: 'Hiểu _layout.tsx', notes: 'Layout tổ chức navigator và provider.', completed: false },
  { id: '2', title: 'Mở một dynamic route', notes: 'ID thuộc URL; dữ liệu được đọc từ Context.', completed: true },
];

const TasksContext = createContext<TasksState | null>(null);

export function TasksProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const nextId = useRef(3);

  function addTask(title: string, notes: string) {
    const id = String(nextId.current++);
    const task: Task = { id, title: title.trim(), notes: notes.trim(), completed: false };
    setTasks((current) => [task, ...current]);
    return id;
  }

  function toggleTask(id: string) {
    setTasks((current) => current.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task,
    ));
  }

  return (
    <TasksContext.Provider value={{ tasks, addTask, toggleTask }}>
      {children}
    </TasksContext.Provider>
  );
}

export function useTasks() {
  const context = useContext(TasksContext);
  if (!context) throw new Error('useTasks phải nằm trong TasksProvider.');
  return context;
}
