# Expo Router Lab · SDK 57

Đây là một project mẫu độc lập để thực hành cùng tài liệu HTML. Giải nén vào một thư mục riêng; không chép đè thư mục `src` của project đang làm.

## Chạy mẫu

Yêu cầu Node.js 22.13.x trở lên, npm và môi trường Expo/iOS Simulator đã hoạt động. Mẫu dùng Expo 57.0.30, Expo Router 57.0.28, React 19.2.3, React Native 0.86.3. Sau khi giải nén, mở Terminal ngay trong thư mục chứa `package.json`:

```sh
npm install
npm run typecheck
npm run ios
```

`npm run ios` chạy `expo start --ios`: khởi động Metro rồi mở Expo Go tương thích trong Simulator. Có thể phải dừng Metro của project cũ, hoặc chọn cổng khác khi CLI hỏi. Mẫu chưa có development build riêng. Bạn cũng có thể dùng `npm run android` hoặc `npm run web` khi môi trường tương ứng đã sẵn sàng.

Nếu thêm package sau này, dùng `npx expo install <tên-package>` để chọn phiên bản tương thích SDK. `npm install` phía trên chỉ cài bộ phiên bản đã khai báo trong mẫu. Nếu nghi ngờ lệch phiên bản: `npx expo install --check`.

## Thực hành theo thứ tự

1. Mở app: `/` tự chuyển đến `/tasks`. Có 2 công việc và 2 tab Công việc/Ghi chú.
2. Bấm một công việc: mở `/tasks/1?tags=router,lab` hoặc `/tasks/2?tags=router,lab`. Tab bar biến mất vì detail thuộc Root Stack, nằm ngoài `(tabs)`.
3. Bấm “Đánh dấu hoàn thành”, rồi Back: danh sách và bộ đếm đã cập nhật nhờ Context dùng chung.
4. Bấm “Tạo công việc”: `/tasks/new` mở dạng modal; trên iOS có thể kéo xuống để hủy.
5. Bấm Lưu với tiêu đề ngắn: thấy lỗi validation. Nhập ít nhất 3 ký tự và lưu: tạo task, thay form bằng detail bằng `router.replace`. Back về danh sách, không về form vừa lưu.
6. Chuyển tab Ghi chú: bộ đếm giữ dữ liệu vì TasksProvider vẫn được mount ở root layout.
7. Reload toàn bộ app: chỉ còn 2 công việc ban đầu. Dữ liệu trong bộ nhớ, chưa có AsyncStorage/API. Fast Refresh có thể giữ hoặc reset state và không phải cơ chế lưu dữ liệu.

## Cấu trúc route

```text
src/app/
├── _layout.tsx                 Root Stack + TasksProvider
├── (tabs)/
│   ├── _layout.tsx             JavaScript Tabs
│   ├── index.tsx               / → Redirect /tasks, tab ẩn
│   ├── tasks/index.tsx         /tasks
│   └── settings.tsx            /settings
├── tasks/
│   ├── [id].tsx                /tasks/:id
│   └── new.tsx                 /tasks/new, presentation: modal
└── +not-found.tsx              URL không khớp route
```

`(tabs)` tổ chức navigator, không xuất hiện trong URL công khai. Trong `Tabs.Screen`, `name="tasks/index"` là tên route con tương đối với layout; `href="/(tabs)/tasks"` là đường dẫn điều hướng có group để chỉ rõ nhánh. Trong Root Stack, `name="tasks/[id]"` tham chiếu route detail. `new.tsx` tĩnh được ưu tiên trước `[id].tsx`, nên `/tasks/new` mở form.

Route `/` nằm trong `(tabs)/index.tsx` và chuyển tới `/tasks`. Trong Tabs layout, `Tabs.Screen name="index" options={{ href: null }}` ẩn nút tab của route chuyển hướng này. Chỉ có hai nút Công việc/Ghi chú. `href: null` chỉ ẩn nút tab, không cấm truy cập route và không phải cơ chế phân quyền. Đặt redirect trong group giúp Root Stack chỉ có một màn hình nền `(tabs)` khi dùng anchor.

`TaskRow` ở `src/components`; Context ở `src/contexts`: chúng không nằm trong thư mục route. App sử dụng APIs điều hướng từ `expo-router`, không import `@react-navigation/*`.

Nút “Về danh sách” dùng `Link dismissTo`: quay lùi đến danh sách đã có trong stack; nếu không có, Router thay màn hình hiện tại bằng danh sách. Cách này tránh chồng thêm một bản danh sách khi đi từ detail về.

## Deep link và trường hợp lỗi

- Trong Expo Go, lấy địa chỉ dev server thật từ Terminal. Đường dẫn mẫu có dạng `exp://<host>:<port>/--/tasks/1?tags=router,lab`; thay host/port bằng giá trị thực tế. Không dùng `mytasks-router-lab://...` để mở Expo Go.
- Scheme `mytasks-router-lab` được dùng khi build native app riêng từ cấu hình mẫu. Khi đã cài app build đó, đường dẫn tương ứng là `mytasks-router-lab://tasks/1`.
- Root `unstable_settings.anchor = '(tabs)'` giữ Tabs ở phía dưới khi mở thẳng detail/modal. `Tabs.initialRouteName="tasks/index"` chọn danh sách làm tab mặc định.
- `/tasks/999` khớp `[id]`, nhưng Context không có ID nên hiển thị “Không tìm thấy công việc”. Đây là lỗi dữ liệu, không phải route 404.
- `/khong-ton-tai` không khớp route nên dùng `+not-found.tsx`.
- ID task mới (ví dụ 3) không còn trong Context sau khi reload. Điều hướng sâu đến ID đó sẽ báo không tìm thấy dữ liệu.
- `id` và `tags` được kiểm tra/chuẩn hóa lúc chạy. Generic TypeScript của `useLocalSearchParams` không xác thực dữ liệu bên ngoài.

Mẫu tắt `experiments.typedRoutes` để code không phụ thuộc file type được sinh trước khi khởi chạy. Trong project thật, bạn có thể bật nó để tăng kiểm tra `href`, rồi khởi động Expo để sinh route types. Tham số URL vẫn cần kiểm tra lúc chạy.

## Nguồn đối chiếu

- [Router SDK 57](https://docs.expo.dev/versions/v57.0.0/sdk/router/)
- [Installation](https://docs.expo.dev/router/installation/)
- [Navigation](https://docs.expo.dev/router/basics/navigation/)
- [JavaScript tabs](https://docs.expo.dev/router/advanced/tabs/)
- [Modals](https://docs.expo.dev/router/advanced/modals/)
- [URL parameters](https://docs.expo.dev/router/reference/url-parameters/)

Đây là lab điều hướng, chưa triển khai đăng nhập, lưu trữ bền vững, backend hay đồng bộ dữ liệu.
