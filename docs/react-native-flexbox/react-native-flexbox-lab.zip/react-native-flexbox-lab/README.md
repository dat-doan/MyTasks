# Flexbox Lab — React Native 0.86 / Expo SDK 57

Project thực hành độc lập cho tài liệu Flexbox tiếng Việt. Không chép đè lên app `my-tasks`.

## Chạy

1. Giải nén vào một thư mục riêng, ví dụ `react-native-flexbox-lab`.
2. Dùng Node.js từ **22.13.0** trở lên và mở Terminal trong thư mục đó.
3. Cài các phiên bản đã khai báo: `npm install`.
4. Kiểm tra kiểu: `npm run typecheck`.
5. Mở iOS Simulator có sẵn: `npm run ios`. Hoặc `npm run android`, `npm start` rồi mở bằng Expo Go tương thích SDK 57.

Trên macOS, iOS Simulator cần Xcode và công cụ Simulator. Bạn cũng có thể dùng thiết bị thật có Expo Go. Các native modules trong mẫu đều có sẵn trong Expo Go. Để thêm thư viện về sau, dùng `npx expo install <package>`; không chọn phiên bản native bằng `npm add`.

`npm install` ở trên chỉ khôi phục dependency đã được khai báo trong gói mẫu. Không cần tạo thư mục `ios/` hoặc `android/`.

## Các file cần đọc

```text
src/app/
  _layout.tsx   Stack, tắt native header để mỗi screen tự vẽ header
  index.tsx     Menu ba bài thực hành
  axes.tsx      Đổi flexDirection, justifyContent, alignItems
  tasks.tsx     Header + hàng input + FlatList co giãn + footer
  form.tsx      ScrollView, contentContainerStyle, flexGrow, auto margin
```

Expo Router cung cấp safe-area context. Mỗi screen dùng `SafeAreaView` từ `react-native-safe-area-context` cho đủ bốn cạnh vì native header đã tắt. Nếu tích hợp vào Stack có header mặc định, cần tránh áp safe-area cạnh trên hai lần và tính lại offset bàn phím.

## Bài tập 1: Trục

- Khung demo cao 260 đơn vị độc lập mật độ điểm ảnh, padding 12, gap 8, ba ô mặc định 48 × 48.
- Đổi `column` sang `row`; kiểm tra hướng tác động của `justifyContent` và `alignItems`.
- Đổi sang giá trị `reverse`; số trên ô vẫn phản ánh thứ tự JSX.
- Chọn `stretch`. Ban đầu ô còn kích thước cố định trên trục chéo, nên chưa kéo dài. Bật “Bỏ kích thước cố định trên trục chéo” để quan sát khác biệt.
- Mỗi ô có `flexShrink: 0` để giữ kích thước trong bài này.

## Bài tập 2: Task list

- `KeyboardAvoidingView`, `SafeAreaView` và `FlatList` có `flex: 1` để truyền chiều cao bị giới hạn từ màn hình xuống list.
- Header, hàng input, footer dùng chiều cao theo nội dung; list nhận phần còn lại.
- Hàng task dùng `flexDirection: "row"`, `gap: 12`. Khối text dùng `flex: 1`, nút kiểm có `flexShrink: 0`.
- Tên task mặc định xuống dòng tự nhiên, không bị cắt. Thử thêm `numberOfLines={2}` vào `Text` để thấy lựa chọn cắt còn hai dòng; đó là chính sách hiển thị chứ không phải cách sửa constraint sai.
- Thêm 20 việc; list cuộn còn footer ở ngoài list luôn nằm trong viewport.
- Đổi cỡ chữ hệ thống. Không đặt chiều cao cố định cho cả hàng text.
- Dữ liệu ở `useState`, cập nhật bằng mảng/object mới; reload hoặc rời screen bị unmount sẽ mất state.

## Bài tập 3: ScrollView và form

- `style={flex: 1}` cấp viewport phần chiều cao còn lại.
- `contentContainerStyle={flexGrow: 1}` cho content ít nhất lấp viewport nhưng vẫn lớn lên theo nội dung.
- `marginTop: "auto"` trên footer hút khoảng trống dương phía trên nó khi nội dung ngắn. Khi content dài, footer nằm cuối luồng cuộn.
- Bấm “Thêm nội dung dài”, cuộn đến cuối và mở bàn phím để kiểm tra.
- Form không lưu dữ liệu, nút “Lưu thử” chỉ cập nhật state.

## Bàn phím và giới hạn mẫu

`KeyboardAvoidingView` ở gốc màn hình, không có native Stack header; iOS dùng `behavior="padding"`, offset mặc định 0. Android dùng xử lý resize của cửa sổ theo cấu hình runtime. Hãy kiểm tra trên Simulator/thiết bị đích: keyboard, rotation, cỡ chữ lớn, màn hình nhỏ. Mẫu không thay thế việc kiểm thử bàn phím khi tích hợp navigator/header/tab bar riêng.

Các kích thước số như `48`, `260` là đơn vị layout độc lập mật độ, không đồng nghĩa số pixel vật lý. Fixed size trong màn hình trục là dụng cụ minh hoạ; màn hình task dùng chiều cao theo nội dung.

## Kiểm tra

```sh
npm run typecheck
npm run lint
```

Gói mẫu chưa kèm ESLint để giữ dependency học Flexbox tối thiểu. Lần đầu chạy `npm run lint`, Expo CLI sẽ hướng dẫn cài/cấu hình ESLint; bạn có thể đồng ý trong project lab. TypeScript không thay thế lint. Dùng `npx expo export --platform ios` để kiểm tra Metro có thể tạo bundle; export thành công không chứng minh UI đã được kiểm thử trên thiết bị.

## Nguồn

- https://reactnative.dev/docs/0.86/flexbox
- https://reactnative.dev/docs/0.86/scrollview
- https://reactnative.dev/docs/0.86/flatlist
- https://reactnative.dev/docs/0.86/keyboardavoidingview
- https://docs.expo.dev/versions/v57.0.0/
- https://docs.expo.dev/versions/v57.0.0/sdk/safe-area-context/
- https://docs.expo.dev/router/basics/navigation/

## Kết quả kiểm tra khi soạn tài liệu

Xem báo cáo đi kèm tài liệu. Mẫu được kiểm tra kiểu và bundle với bộ dependency SDK 57 có sẵn; không tự khẳng định đã chạy thử màn hình trên Simulator hay thiết bị.
