import { useState } from "react";
import { Link } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View, type ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const directions = ["column", "row", "column-reverse", "row-reverse"] as const;
const justifies = ["flex-start", "center", "flex-end", "space-between", "space-around", "space-evenly"] as const;
const aligns = ["flex-start", "center", "flex-end", "stretch"] as const;

export default function AxesScreen() {
  const [direction, setDirection] = useState<(typeof directions)[number]>("column");
  const [justify, setJustify] = useState<(typeof justifies)[number]>("flex-start");
  const [align, setAlign] = useState<(typeof aligns)[number]>("center");
  const [freeCrossSize, setFreeCrossSize] = useState(false);
  const isRow = direction.startsWith("row");
  const tileSize: ViewStyle = isRow
    ? { width: 48, height: freeCrossSize ? undefined : 48 }
    : { height: 48, width: freeCrossSize ? undefined : 48 };

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content}>
        <Link href="/" style={styles.back}>← Về bài thực hành</Link>
        <Text style={styles.title}>Trục chính và trục chéo</Text>
        <Text style={styles.note}>
          Trục chính: {isRow ? "ngang" : "dọc"}. justifyContent theo trục chính;
          alignItems theo trục chéo. Số trên ô là thứ tự trong JSX.
        </Text>
        <Text style={styles.label}>flexDirection</Text>
        <View style={styles.options}>
          {directions.map((value) => (
            <Pressable key={value} onPress={() => setDirection(value)}
              accessibilityRole="button" accessibilityState={{ selected: direction === value }}
              style={[styles.chip, direction === value && styles.active]}>
              <Text style={[styles.chipText, direction === value && styles.activeText]}>{value}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.label}>justifyContent</Text>
        <View style={styles.options}>
          {justifies.map((value) => (
            <Pressable key={value} onPress={() => setJustify(value)}
              accessibilityRole="button" accessibilityState={{ selected: justify === value }}
              style={[styles.chip, justify === value && styles.active]}>
              <Text style={[styles.chipText, justify === value && styles.activeText]}>{value}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.label}>alignItems</Text>
        <View style={styles.options}>
          {aligns.map((value) => (
            <Pressable key={value} onPress={() => setAlign(value)}
              accessibilityRole="button" accessibilityState={{ selected: align === value }}
              style={[styles.chip, align === value && styles.active]}>
              <Text style={[styles.chipText, align === value && styles.activeText]}>{value}</Text>
            </Pressable>
          ))}
        </View>
        <Pressable style={styles.toggle} onPress={() => setFreeCrossSize((value) => !value)}
          accessibilityRole="checkbox" accessibilityState={{ checked: freeCrossSize }}>
          <Text style={styles.note}>{freeCrossSize ? "☑" : "☐"} Bỏ kích thước cố định trên trục chéo</Text>
        </Pressable>
        <View style={[styles.frame, { flexDirection: direction, justifyContent: justify, alignItems: align }]}>
          {["#007C78", "#3068DB", "#BE5828"].map((color, index) => (
            <View key={color} style={[styles.tile, tileSize, { backgroundColor: color }]}>
              <Text style={styles.tileText}>{index + 1}</Text>
            </View>
          ))}
        </View>
        <Text style={styles.note}>
          Khung cao 260, padding 12, gap 8; ô mặc định 48 × 48 và flexShrink: 0.
          Stretch chỉ có thể kéo theo trục chéo khi kích thước trên trục đó để tự động.
          Khi chọn stretch, hãy bật ô kiểm phía trên.
        </Text>
        <View style={styles.code}>
          <Text selectable style={styles.codeText}>
            {`{ flexDirection: "${direction}",\n  justifyContent: "${justify}",\n  alignItems: "${align}",\n  height: 260, padding: 12, gap: 8 }`}
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F4F7FB" },
  content: { padding: 20, gap: 12 },
  back: { color: "#007C78", fontSize: 16, paddingVertical: 8 },
  title: { color: "#10243A", fontSize: 26, fontWeight: "800" },
  label: { color: "#10243A", fontSize: 16, fontWeight: "700", marginTop: 8 },
  note: { color: "#42566C", fontSize: 15, lineHeight: 23 },
  options: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { minHeight: 44, paddingHorizontal: 12, paddingVertical: 10, justifyContent: "center", borderRadius: 10, backgroundColor: "#E2EAF3" },
  active: { backgroundColor: "#007C78" },
  chipText: { color: "#273D54", fontSize: 14 },
  activeText: { color: "white", fontWeight: "700" },
  toggle: { minHeight: 44, justifyContent: "center" },
  frame: { height: 260, padding: 12, gap: 8, borderWidth: 2, borderColor: "#8DA7BC", backgroundColor: "white", borderRadius: 12 },
  tile: { flexShrink: 0, justifyContent: "center", alignItems: "center", borderRadius: 6 },
  tileText: { color: "white", fontSize: 18, fontWeight: "800" },
  code: { backgroundColor: "#10243A", padding: 16, borderRadius: 12 },
  codeText: { color: "#D7E9F6", fontSize: 13, lineHeight: 21, fontFamily: "monospace" },
});
