import { useRef, useState } from "react";
import { Link } from "expo-router";
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

type Task = { id: string; title: string; done: boolean };
const initialTasks: Task[] = [
  { id: "1", title: "Đọc trục chính trước khi chọn justifyContent", done: false },
  { id: "2", title: "Thử một tiêu đề rất dài để kiểm tra khối text được cấp chiều rộng còn lại và tự xuống dòng mà không đẩy nút thao tác ra ngoài màn hình", done: false },
  { id: "3", title: "Quan sát FlatList chiếm phần chiều cao còn lại", done: true },
];

export default function TasksScreen() {
  const [tasks, setTasks] = useState(initialTasks);
  const [draft, setDraft] = useState("");
  const nextId = useRef(4);
  const doneCount = tasks.filter((task) => task.done).length;

  function addTask() {
    const title = draft.trim();
    if (!title) return;
    const task: Task = { id: String(nextId.current++), title, done: false };
    setTasks((current) => [...current, task]);
    setDraft("");
  }

  function toggleTask(id: string) {
    setTasks((current) => current.map((task) => task.id === id ? { ...task, done: !task.done } : task));
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <Link href="/" style={styles.back}>← Về bài thực hành</Link>
          <Text style={styles.heading}>Việc cần làm</Text>
          <Text style={styles.hint}>Header tự cao · list flex: 1 · footer tự cao</Text>
        </View>
        <View style={styles.inputRow}>
          <TextInput value={draft} onChangeText={setDraft} onSubmitEditing={addTask}
            placeholder="Nhập một việc mới" accessibilityLabel="Tên việc cần làm"
            returnKeyType="done" style={styles.input} />
          <Pressable onPress={addTask} accessibilityRole="button" style={styles.addButton}>
            <Text style={styles.addText}>Thêm</Text>
          </Pressable>
        </View>
        <FlatList style={styles.list} contentContainerStyle={styles.listContent}
          keyboardShouldPersistTaps="handled" data={tasks} keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.taskRow}>
              <View style={styles.taskBody}>
                <Text style={[styles.taskTitle, item.done && styles.doneTitle]}>{item.title}</Text>
                <Text style={styles.hint}>id: {item.id} · khối text dùng flex: 1</Text>
              </View>
              <Pressable onPress={() => toggleTask(item.id)} accessibilityRole="checkbox"
                accessibilityLabel={`Hoàn thành: ${item.title}`} accessibilityState={{ checked: item.done }}
                style={[styles.check, item.done && styles.checked]}>
                <Text style={[styles.checkText, item.done && styles.checkedText]}>{item.done ? "✓" : "○"}</Text>
              </Pressable>
            </View>
          )} />
        <View style={styles.footer}>
          <Text style={styles.footerTitle}>{doneCount}/{tasks.length} việc hoàn thành</Text>
          <Text style={styles.hint}>Thêm nhiều việc để list cuộn. Footer ở ngoài list nên vẫn nằm trong viewport.</Text>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F4F7FB" },
  safeArea: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16, gap: 8 },
  back: { color: "#007C78", fontSize: 16, paddingVertical: 8 },
  heading: { color: "#10243A", fontSize: 28, fontWeight: "800" },
  hint: { color: "#53687D", fontSize: 13, lineHeight: 20 },
  inputRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 20, paddingBottom: 16 },
  input: { flex: 1, minHeight: 48, paddingHorizontal: 12, paddingVertical: 10, borderWidth: 1, borderColor: "#B8C9D7", borderRadius: 10, backgroundColor: "white", fontSize: 16, color: "#10243A" },
  addButton: { flexShrink: 0, minHeight: 48, justifyContent: "center", paddingHorizontal: 16, borderRadius: 10, backgroundColor: "#007C78" },
  addText: { color: "white", fontSize: 16, fontWeight: "700" },
  list: { flex: 1 },
  listContent: { paddingHorizontal: 20, paddingBottom: 16, gap: 12 },
  taskRow: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16, borderRadius: 14, backgroundColor: "white" },
  taskBody: { flex: 1, gap: 6 },
  taskTitle: { color: "#10243A", fontSize: 16, lineHeight: 24 },
  doneTitle: { textDecorationLine: "line-through", color: "#6F8293" },
  check: { flexShrink: 0, minWidth: 48, minHeight: 48, padding: 8, alignItems: "center", justifyContent: "center", borderRadius: 12, borderWidth: 1, borderColor: "#B8C9D7" },
  checked: { backgroundColor: "#007C78", borderColor: "#007C78" },
  checkText: { color: "#007C78", fontSize: 24 },
  checkedText: { color: "white" },
  footer: { paddingHorizontal: 20, paddingVertical: 16, gap: 4, borderTopWidth: 1, borderColor: "#DDE6EF", backgroundColor: "#E6F3EF" },
  footerTitle: { color: "#10243A", fontSize: 16, fontWeight: "700" },
});
