import { useState } from "react";
import { Link } from "expo-router";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function FormScreen() {
  const [longContent, setLongContent] = useState(false);
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
          <Link href="/" style={styles.back}>← Về bài thực hành</Link>
          <Text style={styles.title}>Form ngắn và dài</Text>
        </View>
        <ScrollView style={styles.viewport} contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled">
          <View style={styles.body}>
            <Text style={styles.description}>
              ScrollView là viewport có flex: 1. Khối content bên trong dùng flexGrow: 1 để ít nhất
              lấp đầy viewport, nhưng vẫn có thể dài hơn để cuộn.
            </Text>
            <Text style={styles.label}>Tên hiển thị</Text>
            <TextInput style={styles.input} value={name} onChangeText={(value) => { setName(value); setSaved(false); }}
              placeholder="Tên của bạn" accessibilityLabel="Tên hiển thị" />
            <Pressable onPress={() => setLongContent((value) => !value)} style={styles.toggle} accessibilityRole="button">
              <Text style={styles.toggleText}>{longContent ? "Ẩn" : "Thêm"} nội dung dài</Text>
            </Pressable>
            {longContent && Array.from({ length: 8 }, (_, index) => (
              <Text key={index} style={styles.description}>
                Đoạn {index + 1}: Content tự tăng chiều cao theo nội dung. Footer tham gia normal flow,
                nên khi nội dung dài nó nằm cuối phần cuộn, không đè lên chữ.
              </Text>
            ))}
          </View>
          <View style={styles.footer}>
            <Text style={styles.description}>Footer dùng marginTop: "auto" để nhận khoảng trống khi form ngắn.</Text>
            <Pressable onPress={() => setSaved(true)} style={styles.save} accessibilityRole="button">
              <Text style={styles.saveText}>Lưu thử</Text>
            </Pressable>
            {saved && <Text accessibilityLiveRegion="polite" style={styles.result}>
              Đã nhận: {name.trim() || "Chưa có tên"}. Đây là state tạm, không lưu xuống ổ đĩa.
            </Text>}
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F4F7FB" },
  safeArea: { flex: 1 },
  header: { paddingHorizontal: 20, paddingVertical: 8, gap: 8 },
  back: { color: "#007C78", fontSize: 16, paddingVertical: 8 },
  title: { color: "#10243A", fontSize: 26, fontWeight: "800" },
  viewport: { flex: 1 },
  content: { flexGrow: 1, padding: 20 },
  body: { gap: 16 },
  description: { color: "#42566C", fontSize: 16, lineHeight: 24 },
  label: { color: "#10243A", fontSize: 16, fontWeight: "700" },
  input: { minHeight: 48, padding: 12, backgroundColor: "white", borderWidth: 1, borderColor: "#B8C9D7", borderRadius: 10, color: "#10243A", fontSize: 16 },
  toggle: { minHeight: 48, padding: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#DFF4F0", borderRadius: 10 },
  toggleText: { color: "#007C78", fontSize: 16, fontWeight: "700" },
  footer: { marginTop: "auto", paddingTop: 24, gap: 12 },
  save: { minHeight: 48, alignItems: "center", justifyContent: "center", padding: 12, backgroundColor: "#007C78", borderRadius: 10 },
  saveText: { color: "white", fontSize: 16, fontWeight: "700" },
  result: { color: "#007C78", fontSize: 15, lineHeight: 22 },
});
