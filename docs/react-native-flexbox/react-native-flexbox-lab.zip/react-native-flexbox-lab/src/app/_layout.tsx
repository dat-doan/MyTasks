import { Stack } from "expo-router";

export default function RootLayout() {
  // Mỗi screen tự vẽ header, nên SafeAreaView xử lý cả cạnh trên.
  // KeyboardAvoidingView ở task/form phủ toàn màn hình, không có native header offset.
  return <Stack screenOptions={{ headerShown: false }} />;
}
