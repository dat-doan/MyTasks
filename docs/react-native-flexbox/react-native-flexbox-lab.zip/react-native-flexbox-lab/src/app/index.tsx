import { Link } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>REACT NATIVE · FLEXBOX LAB</Text>
        <Text style={styles.title}>Chạm, đổi style, quan sát layout.</Text>
        <Text style={styles.description}>
          Ba bài thực hành dùng layout native. Mở từng màn hình rồi thay đổi kích thước Simulator,
          tăng cỡ chữ và thử nội dung dài để thấy constraint tác động thế nào.
        </Text>
        <Link href="/axes" asChild>
          <Pressable style={styles.card} accessibilityRole="button">
            <Text style={styles.cardTitle}>01 · Trục chính và trục chéo</Text>
            <Text style={styles.description}>Đổi direction, justifyContent, alignItems và quan sát ba ô.</Text>
          </Pressable>
        </Link>
        <Link href="/tasks" asChild>
          <Pressable style={styles.card} accessibilityRole="button">
            <Text style={styles.cardTitle}>02 · Danh sách task</Text>
            <Text style={styles.description}>Header và footer tự cao, FlatList nhận phần còn lại, text dài co đúng chỗ.</Text>
          </Pressable>
        </Link>
        <Link href="/form" asChild>
          <Pressable style={styles.card} accessibilityRole="button">
            <Text style={styles.cardTitle}>03 · Form ngắn và dài</Text>
            <Text style={styles.description}>So sánh viewport với content; flexGrow: 1 và footer marginTop: auto.</Text>
          </Pressable>
        </Link>
        <View style={styles.note}>
          <Text style={styles.description}>
            Mẫu dùng dữ liệu trong bộ nhớ. Reload app sẽ khởi tạo lại dữ liệu; không có API hay lưu trữ.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F4F7FB" },
  content: { padding: 20, gap: 16 },
  eyebrow: { fontSize: 12, fontWeight: "700", color: "#007C78", letterSpacing: 1 },
  title: { fontSize: 30, fontWeight: "800", color: "#10243A" },
  description: { fontSize: 16, lineHeight: 24, color: "#42566C" },
  card: { padding: 20, gap: 8, backgroundColor: "white", borderRadius: 16, borderWidth: 1, borderColor: "#DDE6EF" },
  cardTitle: { fontSize: 19, fontWeight: "700", color: "#10243A" },
  note: { padding: 16, borderRadius: 12, backgroundColor: "#DFF4F0" },
});
